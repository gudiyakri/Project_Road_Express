const CONSTANTS = {
	email: "####",
	pass: "####",
	host: "localhost",
	user: "root",
	password: "",
	database: "road_exp_test",
	firebaseUrl: "####",
	loadUrl: "####",
};

module.exports = CONSTANTS;
